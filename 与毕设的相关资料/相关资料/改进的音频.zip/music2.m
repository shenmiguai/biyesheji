[y,fs]=audioread('庐州月_2_1.wav');  %样本数据y 和采样率fs
N=length(y); %采样点数
 y=y(:,1);
X=fft(y);
X=abs(X/N);
X=X(1:N/2+1);
X(2:end-1)=2*X(2:end-1);
f1=fs*(0:(N/2))/N;
figure;
subplot(2,1,1);plot(y);title('原始信号时域波形图');
w1=2/fs*f1;
subplot(2,1,2);plot(w1,X); title('原始语音信号采样后的频谱图');xlabel("归一化频率/\pi rad");


%%
%加噪

noise_rand=0.1*randn(N,1);

Fs = 44100;  % Sampling Frequency

Fstop = 11025;           % Stopband Frequency
Fpass = 11200;           % Passband Frequency
Dstop = 0.0001;          % Stopband Attenuation
Dpass = 0.057501127785;  % Passband Ripple
dens  = 20;              % Density Factor

% Calculate the order from the parameters using FIRPMORD.
[NN, Fo, Ao, W] = firpmord([Fstop, Fpass]/(Fs/2), [0 1], [Dstop, Dpass]);

% Calculate the coefficients using the FIRPM function.
b  = firpm(NN, Fo, Ao, W, {dens});
Hd = dfilt.dffir(b);
hpf_noise = filter(Hd,noise_rand);


noise_fft=fft(noise_rand);
noise_fft=abs(noise_fft/N);
noise_fft=noise_fft(1:N/2+1);
noise_fft(2:end-1)=2*noise_fft(2:end-1);

hpf_fft=fft(hpf_noise);
hpf_fft=abs(hpf_fft/N);
hpf_fft=hpf_fft(1:N/2+1);
hpf_fft(2:end-1)=2*hpf_fft(2:end-1);

figure;
subplot(4,1,1);
plot(noise_rand);title('高斯白噪声时域图');
subplot(4,1,2);
plot(w1,noise_fft);title('高斯白噪声频谱图');xlabel("归一化频率/\pi rad");
subplot(4,1,3);
plot(hpf_noise);title('带限高斯白噪声时域图');
subplot(4,1,4);
plot(w1,hpf_fft);title('带限高斯白噪声频谱图');xlabel("归一化频率/\pi rad");

figure;
y_n=y+hpf_noise;
X_n=fft(y_n);
X_n=abs(X_n/N);
X_n=X_n(1:N/2+1);
X_n(2:end-1)=2*X_n(2:end-1);
subplot(2,1,1);plot(y_n);title('音频信号加带限噪声后的时域图')
subplot(2,1,2);plot(w1,X_n); title('音频信号加带限噪声后的频谱图');xlabel("归一化频率/\pi rad");
%%
%去噪
fcuts = [0.45  0.5]; %归一化频率omega/pi，这里指通带截止频率、阻带起始频率
mags = [1 0];
devs = [0.05 10^(-2.5)];
[n,Wn,beta,ftype] = kaiserord(fcuts,mags,devs);  %计算出凯塞窗N，beta的值
hh = fir1(n,Wn,ftype,kaiser(n+1,beta),'noscale'); 
figure;
freqz(hh);
%使用滤波器
 y_f=filter(hh,Wn,y_n);
X_f=fft(y_f);
X_f=abs(X_f/N);
X_f=X_f(1:N/2+1);
X_f(2:end-1)=2*X_f(2:end-1);
figure;

subplot(2,1,1);plot(w1,X_n); title('滤波前频谱');xlabel("归一化频率/\pi rad");
subplot(2,1,2);plot(w1,X_f); title('滤波后频谱');xlabel("归一化频率/\pi rad");
% sound(y,fs);  %%听原始音频
% sound(y_n,fs);  %%听加噪音频
% sound(y_f,fs);  %%听去噪音频
% clear sound  %%终止播放